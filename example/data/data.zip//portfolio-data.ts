// Portfolio data structure - replace this with your actual content from GitHub
// To get your actual content, you can:
// 1. Copy the content from your GitHub pages repository
// 2. Export your existing data structure
// 3. Convert your markdown/HTML content to this TypeScript format

export interface Publication {
  title: string;
  authors: string;
  venue: string;
  year: string;
  type: 'Conference Paper' | 'Journal Article' | 'Workshop Paper' | 'Technical Report';
  url?: string;
  abstract?: string;
}

export interface Project {
  title: string;
  description: string;
  technologies: string[];
  status: 'Active' | 'Completed' | 'In Progress';
  url?: string;
  githubUrl?: string;
  imageUrl?: string;
}

export interface ResearchArea {
  title: string;
  description: string;
  keywords: string[];
}

export interface PersonalInfo {
  name: string;
  title: string;
  institution: string;
  location: string;
  email: string;
  bio: string;
  profileImage?: string;
  cv?: string;
}

// REPLACE THIS DATA WITH YOUR ACTUAL CONTENT FROM GITHUB
export const personalInfo: PersonalInfo = {
  name: "Josh Chin",
  title: "Computer Scientist | Researcher | Educator",
  institution: "Academic Institution", // Replace with your actual institution
  location: "Your Location", // Replace with your actual location
  email: "your.email@institution.edu", // Replace with your actual email
  bio: `Replace this with your actual bio from your GitHub repository. 
        This should be the content from your about section or main README.`,
  // profileImage: "/path/to/your/image.jpg", // Add your actual profile image
  // cv: "/path/to/your/cv.pdf" // Add link to your CV
};

export const researchAreas: ResearchArea[] = [
  // Replace these with your actual research areas from GitHub
  {
    title: "Your Research Area 1",
    description: "Description from your GitHub repository",
    keywords: ["keyword1", "keyword2", "keyword3"]
  },
  {
    title: "Your Research Area 2", 
    description: "Description from your GitHub repository",
    keywords: ["keyword1", "keyword2", "keyword3"]
  },
  // Add more research areas as needed
];

export const publications: Publication[] = [
  // Replace these with your actual publications from GitHub
  {
    title: "Your Publication Title 1",
    authors: "Your actual author list",
    venue: "Actual venue name",
    year: "2024",
    type: "Conference Paper",
    url: "https://link-to-your-paper.com"
  },
  {
    title: "Your Publication Title 2",
    authors: "Your actual author list", 
    venue: "Actual venue name",
    year: "2023",
    type: "Journal Article",
    url: "https://link-to-your-paper.com"
  },
  // Add more publications as needed
];

export const projects: Project[] = [
  // Replace these with your actual projects from GitHub
  {
    title: "Your Project 1",
    description: "Description from your GitHub repository",
    technologies: ["Tech1", "Tech2", "Tech3"],
    status: "Active",
    url: "https://your-project-url.com",
    githubUrl: "https://github.com/csjoshc/your-repo"
  },
  {
    title: "Your Project 2",
    description: "Description from your GitHub repository", 
    technologies: ["Tech1", "Tech2"],
    status: "Completed",
    githubUrl: "https://github.com/csjoshc/your-repo"
  },
  // Add more projects as needed
];

// Social media links - update with your actual profiles
export const socialLinks = {
  github: "https://github.com/csjoshc",
  linkedin: "https://linkedin.com/in/csjoshc", // Update if different
  twitter: "", // Add if you have Twitter
  scholar: "", // Add Google Scholar if you have it
  orcid: "", // Add ORCID if you have it
};